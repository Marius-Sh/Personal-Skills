function buttonDropList() {
    document.getElementById("theDrop").classList.toggle("show-content");
  }
  
//   // Close the dropdown menu if the user clicks outside of it
//   window.onclick = function(event) {
//     if (!event.target.matches('.dropdown-button')) {
//       var dropdowns = document.getElementsByClassName("dropdown-contents-from-button");
//       var i;
//       for (i = 0; i < dropdowns.length; i++) {
//         var openDropdown = dropdowns[i];
//         if (openDropdown.classList.contains('show-content')) {
//           openDropdown.classList.remove('show-content');
//         }
//       }
//     }
//   } 